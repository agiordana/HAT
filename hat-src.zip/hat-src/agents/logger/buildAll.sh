#!/bin/sh

cd ../tinyxml
make;
cd ../minilibs ;
make ; 
cd ../logagent ; 
make ;
